package com.bookclub.bookclub.service.dao;
import com.bookclub.bookclub.model.WishlistItem;
import com.bookclub.bookclub.service.GenericCrudDao;

public interface WishlistDao extends GenericCrudDao<WishlistItem, String>{
    
}
