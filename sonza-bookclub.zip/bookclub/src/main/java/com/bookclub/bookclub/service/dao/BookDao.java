package com.bookclub.bookclub.service.dao;
import com.bookclub.bookclub.model.book;
import com.bookclub.bookclub.service.GenericDao;

public interface BookDao extends GenericDao<book, String>{
    
}
